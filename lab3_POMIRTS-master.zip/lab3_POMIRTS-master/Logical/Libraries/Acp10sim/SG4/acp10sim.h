/* Automation Studio generated header file */
/* Do not edit ! */

#ifndef _ACP10SIM_
#define _ACP10SIM_

#include <bur/plctypes.h>

#ifndef _IEC_CONST
#define _IEC_CONST _WEAK const
#endif

/* Datatypes and datatypes of function blocks */


__asm__(".section \".plc\"");

__asm__(".previous");


#endif /* _ACP10SIM_ */

